$(function(){
    var operacao = "A"; //"A"=Adição; "E"=Edição
    var indice_selecionado = -1; //Índice do item selecionado na lista
    var tbClientes = localStorage.getItem("tbClientes");// Recupera os dados armazenados
    tbClientes = JSON.parse(tbClientes); // Converte string para objeto
    if(tbClientes == null) // Caso não haja conteúdo, iniciamos um vetor vazio
    tbClientes = [];
});
 
function Adicionar(){
    var nome = JSON.stringify({
        unidade   : $("#txtunidade").val(),
        Nome     : $("#txtNome").val(),
        Quantidade : $("#txtQuantidade").val(),
        Preco    : $("#txtPreco").val()
    });
    tbClientes.push(cliente);
    localStorage.setItem("tbClientes", JSON.stringify(tbClientes));
    alert("Registro adicionado.");
    return true;
}
 
function Editar(){
    tbClientes[indice_selecionado] = JSON.stringify({
            unidade   : $("#txtunidade").val(),
            Nome     : $("#txtNome").val(),
            Quantidade : $("#txtQuantidade").val(),
            ProdutoPerecivel : $("#txtProdutoperecivel").val(),
            DataValidade : $("#txtDatavalidade").val(),
            Datafabricacao : $("#txtDatafabricacao").val(),
            Quantidade : $("#txtQuantidade").val(),
            Preco    : $("#txtPreco").val()
        });//Altera o item selecionado na tabela
    localStorage.setItem("tbClientes", JSON.stringify(tbClientes));
    alert("Informações editadas.")
    operacao = "A"; //Volta ao padrão
    return true;
}
 
function Excluir(){
    tbClientes.splice(indice_selecionado, 1);
    localStorage.setItem("tbClientes", JSON.stringify(tbClientes));
    alert("Registro excluído.");
}
 
function Listar(){
    $("#tblListar").html("");
    $("#tblListar").html(
        "<thead>"+
        "   <tr>"+
        "   <th></th>"+
        "   <th>Código</th>"+
        "   <th>Nome</th>"+
        "   <th>Unidade</th>"+
        "   <th>Quantidade</th>"+
        "   <th>Preco</th>"+
        "   <th>Produto Perecivel</th>"+
        "   <th>Data Validade</th>"+
        "   <th>Data de Fabricacao</th>"+
        "   <th>P</th>"+
        "   </tr>"+
        "</thead>"+
        "<tbody>"+
        "</tbody>"
        );
    for(var i in tbClientes){
        var cli = JSON.parse(tbClientes[i]);
        $("#tblListar tbody").append("<tr>");
        $("#tblListar tbody").append("<td><img src='edit.png' alt='"+i+"'
              class='btnEditar'/><img src='delete.png' alt='"+i+"' class='btnExcluir'/></td>");
        $("#tblListar tbody").append("<td>"+cli.unidade+"</td>");
        $("#tblListar tbody").append("<td>"+cli.Nome+"</td>");
        $("#tblListar tbody").append("<td>"+cli.Quantidade+"</td>");
        $("#tblListar tbody").append("<td>"+cli.Preco+"</td>");
        $("#tblListar tbody").append("<td>"+cli.Unidade+"</td>");
        $("#tblListar tbody").append("<td>"+cli.ProdutoPerecivel+"</td>");
        $("#tblListar tbody").append("<td>"+cli.DataValidade+"</td>");
        $("#tblListar tbody").append("<td>"+cli.DataFabricacao+"</td>");
        $("#tblListar tbody").append("</tr>");
    }
}
 
$("#frmCadastro").on("submit",function(){
    if(operacao == "A")
        return Adicionar();
    else
        return Editar();       
});
 
 
$("#tblListar").on("click", ".btnEditar", function(){
    operacao = "E";
    indice_selecionado = parseInt($(this).attr("alt"));
    var cli = JSON.parse(tbClientes[indice_selecionado]);
    $("#txtunidade").val(cli.unidade);
    $("#txtNome").val(cli.Nome);
    $("#txtQuantidade").val(cli.Quantidade);
    $("#txtPreco").val(cli.Preco);
    $("#txtDatavalidade").val(cli.Datavalidade);
    $("#txtProduto perecivel").val(cli.ProdutoPerecivel);
    $("#txtDatafabricacao").val(cli.DataFabricacao);
$("#txtunidade").attr("readonly","readonly");
    $("#txtNome").focus();
});
 
$("#tblListar").on("click", ".btnExcluir",function(){
    indice_selecionado = parseInt($(this).attr("alt"));
    Excluir();
    Listar();
});