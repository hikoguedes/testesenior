import { Routes } from '@angular/router';
import { routing } from './app.routing';
import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule  } from '@angular/router';


import { CadastroComponent } from './cadastro/cadastro.component';
import { ListagemComponent } from './listagem/listagem.component';

const CAMINHO_ROTAS: Routes = [

{ path: 'cadastro', component: CadastroComponent},
{ path: 'listagem', component: ListagemComponent}

];

export const routing:  ModuleWithProviders = RouterModule.forRoot(CAMINHO_ROTAS);

